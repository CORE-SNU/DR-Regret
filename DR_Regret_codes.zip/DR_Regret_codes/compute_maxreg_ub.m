L = 0;
UB = inf;
LB = -inf;

while UB - LB > err_tol 

    L = L + 1;

    if L == 1 
    
        q_plus_vec = zeros(N*m, 1);
        q_minus_vec = zeros(N*m, 1);
        lambda_coefficient = (1/N) * sum(q_plus_vec + q_minus_vec); 
        xi_plus_1toN = xi_hat_vec;        
        Ain_wrst_best = [ 
            Ain_x zeros(size(Ain_x,1),N);
            kron(ones(N,1),c_k_trans_matrix) -kron(eye(N),ones(K,1));
            ];
        bin_wrst_best = [
            bin_x;
            -kron(eye(N),b_k_trans_matrix) * xi_hat_vec - kron(ones(N,1),d_k_matrix);
            ];
        f_wrst_best = [ 
            zeros(n_x,1);
            1/N * ones(N,1) 
            ]; 
        [ ~, fval_wrst_best ] = cplexlp(f_wrst_best, Ain_wrst_best, bin_wrst_best);
        Ain_master = [ 
            0 -1 1 zeros(1,N);
            -lambda_coefficient 0 -1 (1/N)*ones(1,N);
            zeros(N*K,3) -kron(eye(N),ones(K,1));
            ];
        bin_master = [
            0;
            fval_wrst_best;             
            -kron(ones(N,1),c_k_trans_matrix)*x - kron(eye(N),b_k_trans_matrix) * xi_plus_1toN - kron(ones(N,1),d_k_matrix);
            ];
        lb_master = [
            0;
            -inf;
            -inf*ones(1+N,1);
            ];
        ub_master = [
            inf;
            inf;
            inf*ones(1+N,1)
            ];
        f_master = [ Was_dist; 1; zeros(1+N, 1) ];        

    else
    
        Ain_master = [
            Ain_master zeros(size(Ain_master, 1), 1 + N);
            zeros(1, 1) -1 zeros(1,(L - 1) * (1 + N)) 1 zeros(1,N);
            -lambda_coefficient 0 zeros(1,(L - 1) * (1 + N)) -1 (1/N)*ones(1,N);
            zeros(N*K, 2) zeros(N*K,(L - 1) * (1 + N)) zeros(N*K,1) -kron(eye(N),ones(K,1));
            ];
        bin_master = [
            bin_master;
            0;
            fval_wrst_best;
            -kron(ones(N, 1), c_k_trans_matrix)*x - kron(eye(N),b_k_trans_matrix) * xi_plus_1toN - kron(ones(N,1),d_k_matrix);
            ];
        ub_master = [
            ub_master;
            inf*ones(1+N,1);
            ]; 
        lb_master = [ 
            lb_master;
            -inf*ones(1+N,1)
            ];
        f_master = [ f_master; zeros(1 + N, 1) ];

    end
    
    %% master problem
    [ sol_master, LB ] = cplexlp(f_master,Ain_master,bin_master,[],[],lb_master,ub_master);
    lambda = sol_master(1);

    %% subproblem 
    Ain_sig_dum = kron(eye(N), [-ones(1,K-1); eye(K-1)]);
    bin_sig_dum = kron(ones(N,1), [0; ones(K-1,1)]); 
    Ain_sub = [ 
        zeros(size(Ain_x,1),(K-1)*N) Ain_x zeros(size(Ain_x,1), N + 2*N*m + N);
        zeros(K*N,(K-1)*N) kron(ones(N, 1), c_k_trans_matrix) -kron(eye(N),ones(K,1)) kron(eye(N),b_k_trans_matrix) -kron(eye(N),b_k_trans_matrix) zeros(N*K,N);        
        G*Ain_sig_dum zeros(N*K,n_x + N) -kron(eye(N),b_k_trans_matrix) kron(eye(N),b_k_trans_matrix) kron(eye(N),ones(K,1));
        G*Ain_sig_dum zeros(N*K,n_x + N) kron(eye(N),b_k_trans_matrix) -kron(eye(N),b_k_trans_matrix) -kron(eye(N),ones(K,1));
        kron(eye(N),ones(1,K-1))  zeros(N, n_x + N + 2*N*m + N)
        zeros(N*size(Ain_xi,1),(K-1)*N + n_x + N) kron(eye(N),Ain_xi) -kron(eye(N),Ain_xi) zeros(N*size(Ain_xi,1), N);             
        ];
    bin_sub = [
        bin_x;
        -kron(eye(N),b_k_trans_matrix) * xi_hat_vec - kron(ones(N,1),d_k_matrix);        
        kron(ones(N, 1), c_k_trans_matrix)*x + kron(eye(N),b_k_trans_matrix)*xi_hat_vec + kron(ones(N,1),d_k_matrix)  + G*bin_sig_dum
        -kron(ones(N, 1), c_k_trans_matrix)*x - kron(eye(N),b_k_trans_matrix)*xi_hat_vec - kron(ones(N,1),d_k_matrix)  + G*bin_sig_dum
        ones(N,1);
        -kron(eye(N),Ain_xi)*xi_hat_vec + kron(ones(N,1),bin_xi)    
        ];
    f_sub = [
        zeros((K-1)*N, 1);
        zeros(n_x, 1);
        (1/N) * ones(N,1);
        (1/N) * lambda * ones(N*m,1);
        (1/N) * lambda * ones(N*m,1);
        -(1/N) * ones(N,1);
        ]; 
    lb_sub = [ 
        zeros((K-1)*N, 1);
        -inf*ones(n_x+N, 1);
        zeros(2*N*m, 1);
        -inf*ones(N, 1);
        ];
    ub_sub = [
        ones((K-1)*N, 1);
        inf*ones(n_x + N + N*m + N*m + N, 1);
        ];
    ctype_sub = [ repmat('B',1,(K-1)*N) repmat('C',1,n_x + N + 2*N*m + N) ];
    
    [ sol_sub, fval_sub ] = cplexmilp(f_sub,Ain_sub,bin_sub,[],[],[],[],[],lb_sub,ub_sub,ctype_sub);
    
    y = sol_sub((K-1)*N + 1 : (K-1)*N + n_x); 
    q_plus_vec = sol_sub((K-1)*N + n_x + N + 1 : (K-1)*N + n_x + N + N*m);
    q_minus_vec = sol_sub((K-1)*N + n_x + N + N*m + 1 : (K-1)*N + n_x + N + N*m + N*m);
    lambda_coefficient = (1/N) * sum(q_plus_vec + q_minus_vec); 
    xi_plus_1toN = xi_hat_vec + q_plus_vec - q_minus_vec;
    
    Ain_wrst_best_y = -kron(eye(N),ones(K,1)); 
    bin_wrst_best_y = -kron(ones(N,1),c_k_trans_matrix) * y - kron(eye(N),b_k_trans_matrix) * xi_plus_1toN - kron(ones(N,1),d_k_matrix);
    f_wrst_best_y =  1/N * ones(N,1); 
    [ ~, fval_wrst_best ] = cplexlp(f_wrst_best_y, Ain_wrst_best_y, bin_wrst_best_y);
    
    UB = Was_dist * lambda - fval_sub; 
        
end
ub_maxreg = UB;
