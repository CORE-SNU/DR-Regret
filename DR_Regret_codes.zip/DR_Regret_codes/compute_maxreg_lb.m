Ain_sig_dum = kron(eye(N), [-ones(1,K-1); eye(K-1)]);
bin_sig_dum = kron(ones(N,1), [0; ones(K-1,1)]); 
Ain_lb_maxreg = [ 
    zeros(size(Ain_x,1),(K-1)*N) Ain_x zeros(size(Ain_x,1), N + 2*N*m + N);
    zeros(K*N,(K-1)*N) kron(ones(N, 1), c_k_trans_matrix) -kron(eye(N),ones(K,1)) kron(eye(N),b_k_trans_matrix) -kron(eye(N),b_k_trans_matrix) zeros(N*K,N);        
    G*Ain_sig_dum zeros(N*K,n_x + N) -kron(eye(N),b_k_trans_matrix) kron(eye(N),b_k_trans_matrix) kron(eye(N),ones(K,1));
    G*Ain_sig_dum zeros(N*K,n_x + N) kron(eye(N),b_k_trans_matrix) -kron(eye(N),b_k_trans_matrix) -kron(eye(N),ones(K,1));
    zeros(1,(K-1)*N + n_x + N) (1/N)*ones(1,N*m) (1/N)*ones(1,N*m) zeros(1,N)
    kron(eye(N),ones(1,K-1))  zeros(N, n_x + N + 2*N*m + N) 
    zeros(N*size(Ain_xi,1),(K-1)*N + n_x + N) kron(eye(N),Ain_xi) -kron(eye(N),Ain_xi) zeros(N*size(Ain_xi,1), N);             
    ];
bin_lb_maxreg = [
    bin_x;
    -kron(eye(N),b_k_trans_matrix) * xi_hat_vec - kron(ones(N,1),d_k_matrix);        
    kron(ones(N, 1), c_k_trans_matrix)*x + kron(eye(N),b_k_trans_matrix)*xi_hat_vec + kron(ones(N,1),d_k_matrix)  + G*bin_sig_dum
    -kron(ones(N, 1), c_k_trans_matrix)*x - kron(eye(N),b_k_trans_matrix)*xi_hat_vec - kron(ones(N,1),d_k_matrix)  + G*bin_sig_dum
    Was_dist;
    ones(N,1);
    -kron(eye(N),Ain_xi)*xi_hat_vec + kron(ones(N,1),bin_xi)            
    ];
f_lb_maxreg = [
    zeros((K-1)*N, 1);
    zeros(n_x, 1);
    (1/N) * ones(N,1);
    zeros(N*m,1);
    zeros(N*m,1);
    -(1/N) * ones(N,1);
    ]; 
lb_lb_maxreg = [ 
    zeros((K-1)*N, 1);
    -inf*ones(n_x+N, 1);
    zeros(2*N*m, 1);
    -inf*ones(N, 1);
    ];
ub_lb_maxreg = [
    ones((K-1)*N, 1);
    inf*ones(n_x + N + N*m + N*m + N, 1);
    ];
ctype_lb_maxreg = [ repmat('B',1,(K-1)*N) repmat('C',1,n_x + N + 2*N*m + N) ];

[ ~, lb_maxreg ] = cplexmilp(f_lb_maxreg,Ain_lb_maxreg,bin_lb_maxreg,[],[],[],[],[],lb_lb_maxreg,ub_lb_maxreg,ctype_lb_maxreg);
lb_maxreg = -lb_maxreg;
