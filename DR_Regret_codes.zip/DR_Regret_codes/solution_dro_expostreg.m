L = 0;
UB = inf;
LB = -inf;

while UB - LB > err_tol 

    L = L + 1; 
    
    if L == 1 
    
        q_plus_vec = zeros(N*m, 1); 
        q_minus_vec = zeros(N*m, 1); 
        lambda_coefficient = (1/N) * sum(q_plus_vec + q_minus_vec); 
        xi_plus_1toN = xi_hat_vec; 
        Ain_wrst_best = [ 
            Ain_x zeros(size(Ain_x,1),1);
            c_k_trans_matrix -ones(K,1);
            ];
        f_wrst_best = [ 
            zeros(n_x,1);
            1;
            ];
        fval_wrst_best = zeros(N,1);
        for i = 1 : N
            bin_wrst_best = [
                bin_x;
                -b_k_trans_matrix * xi_hat_vec( (i-1)*m + 1 : i*m ) - d_k_matrix
                ];
            [ ~, fval_wrst_best(i) ] = cplexlp(f_wrst_best, Ain_wrst_best, bin_wrst_best);
        end
        fval_wrst_best = mean(fval_wrst_best);
        Ain_master = [ 
            Ain_x zeros(size(Ain_x,1), 1 + 1 + 1 + N); 
            zeros(1,n_x) 0 -1 1 zeros(1,N);
            zeros(1,n_x) -lambda_coefficient 0 -1 (1/N)*ones(1,N);
            kron(ones(N,1),c_k_trans_matrix) zeros(N*K,3) -kron(eye(N),ones(K,1));
            ];
        bin_master = [
            bin_x;
            0;
            fval_wrst_best;             
            -kron(eye(N),b_k_trans_matrix) * xi_plus_1toN - kron(ones(N,1),d_k_matrix);
            ];
        lb_master = [
            -inf*ones(n_x,1);
            0;
            -inf;
            -inf*ones(1+N,1);
            ];
        ub_master = [
            inf*ones(n_x,1);
            inf;
            inf;
            inf*ones(1+N,1)
            ];
        f_master = [ zeros(n_x,1); Was_dist; 1; zeros(1+N, 1) ];        

    else
    
        Ain_master = [
            Ain_master zeros(size(Ain_master, 1), 1 + N);
            zeros(1, n_x + 1) -1 zeros(1,(L - 1) * (1 + N)) 1 zeros(1,N);
            zeros(1, n_x) -lambda_coefficient 0 zeros(1,(L - 1) * (1 + N)) -1 (1/N)*ones(1,N);
            kron(ones(N, 1), c_k_trans_matrix) zeros(N*K, 2) zeros(N*K,(L - 1) * (1 + N)) zeros(N*K,1) -kron(eye(N),ones(K,1));
            ];
        bin_master = [
            bin_master;
            0;
            fval_wrst_best;             
            -kron(eye(N),b_k_trans_matrix) * xi_plus_1toN - kron(ones(N,1),d_k_matrix);
            ];
        ub_master = [
            ub_master;
            inf*ones(1+N,1);
            ]; 
        lb_master = [ 
            lb_master;
            -inf*ones(1+N,1)
            ];
        f_master = [ f_master; zeros(1 + N, 1) ];

    end
    
    %% master problem 
    [ sol_master, LB ] = cplexlp(f_master,Ain_master,bin_master,[],[],lb_master,ub_master);    
    x = sol_master(1 : n_x);
    lambda = sol_master(n_x + 1);

    %% subproblem 
    Ain_sig_dum = [-ones(1,K-1); eye(K-1)];
    bin_sig_dum = [0; ones(K-1,1)]; 
    Ain_sub = [ 
        zeros(size(Ain_x,1),(K-1)) Ain_x zeros(size(Ain_x,1), 1 + 2*m + 1);
        zeros(K,K-1) c_k_trans_matrix -ones(K,1) b_k_trans_matrix -b_k_trans_matrix zeros(K,1);        
        G*Ain_sig_dum zeros(K,n_x + 1) -b_k_trans_matrix b_k_trans_matrix ones(K,1);
        G*Ain_sig_dum zeros(K,n_x + 1) b_k_trans_matrix -b_k_trans_matrix -ones(K,1);
        ones(1,K-1)  zeros(1, n_x + 1 + 2*m + 1)
        zeros(size(Ain_xi,1),(K-1) + n_x + 1) Ain_xi -Ain_xi zeros(size(Ain_xi,1),1);         
        ];
    f_sub = [
        zeros(K-1, 1);
        zeros(n_x, 1);
        1;
        lambda * ones(m,1);
        lambda * ones(m,1);
        - 1;
        ]; 
    lb_sub = [ 
        zeros(K-1, 1);
        -inf*ones(n_x+1, 1);
        zeros(2*m, 1);
        -inf;
        ];
    ub_sub = [
        ones(K-1, 1);
        inf*ones(n_x + 1 + m + m + 1, 1);
        ];
    ctype_sub = [ repmat('B',1,K-1) repmat('C',1,n_x + 1 + 2*m + 1) ];
    
    xi_plus_1toN = zeros(N*m,1);
    lambda_coefficient = zeros(N,1);
    fval_wrst_best = zeros(N,1);
    fval_sub = zeros(N,1);
    for i = 1 : N 
        bin_sub = [
            bin_x;
            -b_k_trans_matrix * xi_hat_vec((i-1)*m + 1 : i*m) - d_k_matrix;        
            c_k_trans_matrix * x + b_k_trans_matrix*xi_hat_vec((i-1)*m + 1 : i*m) + d_k_matrix  + G*bin_sig_dum
            -c_k_trans_matrix * x - b_k_trans_matrix*xi_hat_vec((i-1)*m + 1 : i*m) - d_k_matrix  + G*bin_sig_dum
            1;
            -Ain_xi*xi_hat_vec((i-1)*m + 1 : i*m) + bin_xi
            ];
        [ sol_sub, fval_sub(i) ] = cplexmilp(f_sub,Ain_sub,bin_sub,[],[],[],[],[],lb_sub,ub_sub,ctype_sub);
        y = sol_sub( K - 1 + 1 : K - 1 + n_x); 
        q_plus = sol_sub( K - 1 + n_x + 1 + 1 : K - 1 + n_x + 1 + m );
        q_minus = sol_sub( K - 1 + n_x + 1 + m + 1 : K - 1 + n_x + 1 + 2*m );
        xi_plus_i = xi_hat_vec( (i-1)*m + 1 : i*m ) + q_plus - q_minus; 
        
        fval_wrst_best(i,1) = max(b_k_trans_matrix * xi_plus_i + c_k_trans_matrix * y + d_k_matrix); 
        lambda_coefficient(i,1) = sum(q_plus + q_minus); 
        xi_plus_1toN( (i-1)*m + 1 : i*m ) = xi_hat_vec( (i-1)*m + 1 : i*m ) + q_plus - q_minus;
    
    end 
    
    fval_wrst_best = mean(fval_wrst_best);
    lambda_coefficient = mean(lambda_coefficient); 
        
    UB = Was_dist * lambda - mean(fval_sub); 
    
end
